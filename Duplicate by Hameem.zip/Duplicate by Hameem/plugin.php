<?php
/**
 * Plugin Name: Post/Page Duplicate
 * Plugin URI: https://hameem.net/
 * Description: Duplicate WordPress posts and pages with one click.
 * Version: 1.0.0
 * Author: Hameem Kay
 * Author URI: https://hameem.net/
 * Text Domain: duplicate
 */

defined( 'ABSPATH' ) || exit;

// Add Duplicate link to post and page row actions
add_filter( 'post_row_actions', 'duplicate_post_link', 10, 2 );
add_filter( 'page_row_actions', 'duplicate_post_link', 10, 2 );
function duplicate_post_link( $actions, $post ) {
    if ( current_user_can( 'edit_posts' ) ) {
        $actions['duplicate'] = '<a href="' . wp_nonce_url( admin_url( 'admin.php?action=duplicate_post&amp;post=' . $post->ID ), 'duplicate_post_' . $post->ID ) . '" title="' . __( 'Duplicate this item', 'duplicate' ) . '">' . __( 'Duplicate', 'duplicate' ) . '</a>';
    }
    return $actions;
}

// Duplicate post or page
add_action( 'admin_action_duplicate_post', 'duplicate_post' );
function duplicate_post() {
    if ( isset( $_GET['post'] ) && is_numeric( $_GET['post'] ) ) {
        $old_post_id = absint( $_GET['post'] );
        $post = get_post( $old_post_id );
        if ( $post ) {
            $new_post = array(
                'post_title' => $post->post_title . ' (copy)',
                'post_name' => sanitize_title_with_dashes( $post->post_title ) . '-copy',
                'post_content' => $post->post_content,
                'post_excerpt' => $post->post_excerpt,
                'post_status' => 'draft',
                'post_type' => $post->post_type,
                'post_author' => get_current_user_id(),
                'comment_status' => $post->comment_status,
                'ping_status' => $post->ping_status,
                'post_parent' => $post->post_parent,
                'menu_order' => $post->menu_order,
                'meta_input' => $post->meta_input,
            );
            $new_post_id = wp_insert_post( $new_post );
            if ( $new_post_id ) {
                $permalink_structure = get_option( 'permalink_structure' );
                if ( empty( $permalink_structure ) ) {
                    update_option( 'permalink_structure', '/%postname%/' );
                }
                wp_redirect( admin_url( 'post.php?action=edit&post=' . $new_post_id ) );
                exit;
            } else {
                wp_die( __( 'Sorry, the post could not be duplicated.', 'duplicate' ) );
            }
        }
    }
}
